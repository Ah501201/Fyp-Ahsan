# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MBRSui.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setWindowModality(QtCore.Qt.NonModal)
        MainWindow.resize(860, 712)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)
        MainWindow.setMinimumSize(QtCore.QSize(860, 712))
        MainWindow.setMaximumSize(QtCore.QSize(860, 712))
        font = QtGui.QFont()
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        font.setKerning(True)
        MainWindow.setFont(font)
        MainWindow.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("Icons/player.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        MainWindow.setWindowOpacity(1.0)
        MainWindow.setStyleSheet("")
        MainWindow.setTabShape(QtWidgets.QTabWidget.Rounded)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.TopFrame = QtWidgets.QFrame(self.centralwidget)
        self.TopFrame.setGeometry(QtCore.QRect(10, 0, 401, 511))
        self.TopFrame.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.TopFrame.setAutoFillBackground(True)
        self.TopFrame.setFrameShape(QtWidgets.QFrame.Panel)
        self.TopFrame.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.TopFrame.setLineWidth(4)
        self.TopFrame.setObjectName("TopFrame")
        self.PicBox = QtWidgets.QLabel(self.TopFrame)
        self.PicBox.setGeometry(QtCore.QRect(20, 10, 361, 241))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.PicBox.sizePolicy().hasHeightForWidth())
        self.PicBox.setSizePolicy(sizePolicy)
        self.PicBox.setAutoFillBackground(False)
        self.PicBox.setFrameShape(QtWidgets.QFrame.Box)
        self.PicBox.setFrameShadow(QtWidgets.QFrame.Raised)
        self.PicBox.setLineWidth(3)
        self.PicBox.setMidLineWidth(0)
        self.PicBox.setText("")
        self.PicBox.setScaledContents(True)
        self.PicBox.setObjectName("PicBox")
        self.OpencameraButton = QtWidgets.QPushButton(self.TopFrame)
        self.OpencameraButton.setGeometry(QtCore.QRect(30, 270, 166, 41))
        self.OpencameraButton.setAutoFillBackground(False)
        self.OpencameraButton.setStyleSheet("QPushButton {\n"
                                            "border: 2px solid #555;\n"
                                            "border-radius: 20px;\n"
                                            "background: qradialgradient(\n"
                                            "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                            "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                            ");\n"
                                            "}\n"
                                            "QPushButton:hover {\n"
                                            "background: qradialgradient(\n"
                                            "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                            "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                            ");\n"
                                            "}")
        self.OpencameraButton.setObjectName("OpencameraButton")
        self.CaptureImageButton = QtWidgets.QPushButton(self.TopFrame)
        self.CaptureImageButton.setGeometry(QtCore.QRect(30, 330, 341, 41))
        self.CaptureImageButton.setStyleSheet("QPushButton {\n"
                                              "border: 2px solid #555;\n"
                                              "border-radius: 20px;\n"
                                              "background: qradialgradient(\n"
                                              "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                              "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                              ");\n"
                                              "}\n"
                                              "QPushButton:hover {\n"
                                              "background: qradialgradient(\n"
                                              "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                              "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                              ");\n"
                                              "}")
        self.CaptureImageButton.setObjectName("CaptureImageButton")
        self.CloseButton = QtWidgets.QPushButton(self.TopFrame)
        self.CloseButton.setGeometry(QtCore.QRect(30, 450, 341, 41))
        self.CloseButton.setAutoFillBackground(False)
        self.CloseButton.setStyleSheet("QPushButton {\n"
                                       "border: 2px solid #555;\n"
                                       "border-radius: 20px;\n"
                                       "background: qradialgradient(\n"
                                       "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                       "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                       ");\n"
                                       "}\n"
                                       "QPushButton:hover {\n"
                                       "background: qradialgradient(\n"
                                       "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                       "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                       ");\n"
                                       "}")
        self.CloseButton.setObjectName("CloseButton")
        self.CreateplaylistButton = QtWidgets.QPushButton(self.TopFrame)
        self.CreateplaylistButton.setGeometry(QtCore.QRect(30, 390, 341, 41))
        self.CreateplaylistButton.setStyleSheet("QPushButton {\n"
                                                "border: 2px solid #555;\n"
                                                "border-radius: 20px;\n"
                                                "background: qradialgradient(\n"
                                                "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                                "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                                ");\n"
                                                "}\n"
                                                "QPushButton:hover {\n"
                                                "background: gradualist(\n"
                                                "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                                "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                                ");\n"
                                                "}")
        self.CreateplaylistButton.setObjectName("CreativelyButton")
        self.OpenFileButton = QtWidgets.QPushButton(self.TopFrame)
        self.OpenFileButton.setGeometry(QtCore.QRect(200, 270, 166, 41))
        font = QtGui.QFont()
        font.setWeight(50)
        self.OpenFileButton.setFont(font)
        self.OpenFileButton.setAutoFillBackground(False)
        self.OpenFileButton.setStyleSheet("QPushButton {\n"
                                          "border: 2px solid #555;\n"
                                          "border-radius: 20px;\n"
                                          "background: qradialgradient(\n"
                                          "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                          "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                          ");\n"
                                          "}\n"
                                          "QPushButton:hover {\n"
                                          "background: qradialgradient(\n"
                                          "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                          "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                          ");\n"
                                          "}")
        self.OpenFileButton.setObjectName("OpenFileButton")
        self.PlaylistFrame = QtWidgets.QFrame(self.centralwidget)
        self.PlaylistFrame.setGeometry(QtCore.QRect(430, 0, 421, 511))
        self.PlaylistFrame.setFrameShape(QtWidgets.QFrame.Panel)
        self.PlaylistFrame.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.PlaylistFrame.setLineWidth(4)
        self.PlaylistFrame.setObjectName("PlaylistFrame")
        self.listWidget = QtWidgets.QListWidget(self.PlaylistFrame)
        self.listWidget.setGeometry(QtCore.QRect(10, 10, 401, 491))
        self.listWidget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.listWidget.setObjectName("listWidget")
        self.PlayerFrame = QtWidgets.QFrame(self.centralwidget)
        self.PlayerFrame.setGeometry(QtCore.QRect(9, 519, 841, 161))
        self.PlayerFrame.setAutoFillBackground(True)
        self.PlayerFrame.setFrameShape(QtWidgets.QFrame.Panel)
        self.PlayerFrame.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.PlayerFrame.setLineWidth(4)
        self.PlayerFrame.setObjectName("PlayerFrame")
        self.MusicSlider = QtWidgets.QSlider(self.PlayerFrame)
        self.MusicSlider.setGeometry(QtCore.QRect(300, 101, 511, 31))
        self.MusicSlider.setOrientation(QtCore.Qt.Horizontal)
        self.MusicSlider.setObjectName("MusicSlider")
        self.VolumeSlider = QtWidgets.QSlider(self.PlayerFrame)
        self.VolumeSlider.setGeometry(QtCore.QRect(670, 40, 141, 41))
        self.VolumeSlider.setOrientation(QtCore.Qt.Horizontal)
        self.VolumeSlider.setObjectName("VolumeSlider")
        self.PlayButton = QtWidgets.QPushButton(self.PlayerFrame)
        self.PlayButton.setGeometry(QtCore.QRect(300, 20, 81, 61))
        self.PlayButton.setStyleSheet("QPushButton {\n"
                                      "border: 2px solid #555;\n"
                                      "border-radius: 20px;\n"
                                      "background: qradialgradient(\n"
                                      "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                      "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                      ");\n"
                                      "}\n"
                                      "QPushButton:hover {\n"
                                      "background: qradialgradient(\n"
                                      "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                      "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                      ");\n"
                                      "}")
        self.PlayButton.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("Icons/play.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.PlayButton.setIcon(icon1)
        self.PlayButton.setIconSize(QtCore.QSize(35, 35))
        self.PlayButton.setObjectName("PlayButton")
        self.PreviousButton = QtWidgets.QPushButton(self.PlayerFrame)
        self.PreviousButton.setGeometry(QtCore.QRect(390, 40, 51, 41))
        self.PreviousButton.setStyleSheet("QPushButton {\n"
                                          "border: 2px solid #555;\n"
                                          "border-radius: 20px;\n"
                                          "background: qradialgradient(\n"
                                          "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                          "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                          ");\n"
                                          "}\n"
                                          "QPushButton:hover {\n"
                                          "background: qradialgradient(\n"
                                          "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                          "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                          ");\n"
                                          "}")
        self.PreviousButton.setText("")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("Icons/Previous.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.PreviousButton.setIcon(icon2)
        self.PreviousButton.setIconSize(QtCore.QSize(28, 28))
        self.PreviousButton.setObjectName("PreviousButton")
        self.NextButton = QtWidgets.QPushButton(self.PlayerFrame)
        self.NextButton.setGeometry(QtCore.QRect(530, 40, 51, 41))
        self.NextButton.setStyleSheet("QPushButton {\n"
                                      "border: 2px solid #555;\n"
                                      "border-radius: 20px;\n"
                                      "background: qradialgradient(\n"
                                      "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                      "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                      ");\n"
                                      "}\n"
                                      "QPushButton:hover {\n"
                                      "background: qradialgradient(\n"
                                      "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                      "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                      ");\n"
                                      "}")
        self.NextButton.setText("")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("Icons/Next.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.NextButton.setIcon(icon3)
        self.NextButton.setIconSize(QtCore.QSize(29, 30))
        self.NextButton.setObjectName("NextButton")
        self.PauseButton = QtWidgets.QPushButton(self.PlayerFrame)
        self.PauseButton.setGeometry(QtCore.QRect(460, 40, 51, 41))
        self.PauseButton.setStyleSheet("QPushButton {\n"
                                       "border: 2px solid #555;\n"
                                       "border-radius: 20px;\n"
                                       "background: qradialgradient(\n"
                                       "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                       "radius: 1.35, stop: 0 #fff, stop: 1 #bbb\n"
                                       ");\n"
                                       "}\n"
                                       "QPushButton:hover {\n"
                                       "background: qradialgradient(\n"
                                       "cx: 0.3, cy: -0.4, fx: 0.3, fy: -0.4,\n"
                                       "radius: 1.35, stop: 0 #fff, stop: 1 #888\n"
                                       ");\n"
                                       "}")
        self.PauseButton.setText("")
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap("Icons/stop.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.PauseButton.setIcon(icon4)
        self.PauseButton.setIconSize(QtCore.QSize(31, 26))
        self.PauseButton.setObjectName("PauseButton")
        self.label = QtWidgets.QLabel(self.PlayerFrame)
        self.label.setGeometry(QtCore.QRect(610, 30, 51, 51))
        self.label.setStyleSheet("")
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("Icons/Volume.png"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.MusicDetailsLabel = QtWidgets.QLabel(self.PlayerFrame)
        self.MusicDetailsLabel.setEnabled(True)
        self.MusicDetailsLabel.setGeometry(QtCore.QRect(10, 10, 261, 141))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.MusicDetailsLabel.sizePolicy().hasHeightForWidth())
        self.MusicDetailsLabel.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("Segoe Script")
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.MusicDetailsLabel.setFont(font)
        self.MusicDetailsLabel.setMouseTracking(True)
        self.MusicDetailsLabel.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.MusicDetailsLabel.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.MusicDetailsLabel.setAutoFillBackground(False)
        self.MusicDetailsLabel.setFrameShape(QtWidgets.QFrame.WinPanel)
        self.MusicDetailsLabel.setFrameShadow(QtWidgets.QFrame.Plain)
        self.MusicDetailsLabel.setLineWidth(1)
        self.MusicDetailsLabel.setMidLineWidth(0)
        self.MusicDetailsLabel.setText("")
        self.MusicDetailsLabel.setTextFormat(QtCore.Qt.RichText)
        self.MusicDetailsLabel.setScaledContents(True)
        self.MusicDetailsLabel.setAlignment(QtCore.Qt.AlignJustify | QtCore.Qt.AlignVCenter)
        self.MusicDetailsLabel.setIndent(-1)
        self.MusicDetailsLabel.setOpenExternalLinks(False)
        self.MusicDetailsLabel.setObjectName("MusicDetailsLabel")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 860, 26))
        self.menubar.setObjectName("menubar")
        self.menuMenu = QtWidgets.QMenu(self.menubar)
        self.menuMenu.setObjectName("menuMenu")
        MainWindow.setMenuBar(self.menubar)
        self.UpdateDatasetButton = QtWidgets.QAction(MainWindow)
        self.UpdateDatasetButton.setObjectName("UpdateDatasetButton")
        self.UpdateModelButton = QtWidgets.QAction(MainWindow)
        self.UpdateModelButton.setObjectName("UpdateModelButton")
        self.menuMenu.addAction(self.UpdateDatasetButton)
        self.menuMenu.addAction(self.UpdateModelButton)
        self.menubar.addAction(self.menuMenu.menuAction())

        self.retranslateUi(MainWindow)
        self.listWidget.setCurrentRow(-1)
        self.CloseButton.clicked.connect(MainWindow.close)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MBRS"))
        self.OpencameraButton.setText(_translate("MainWindow", "Open Camera"))
        self.CaptureImageButton.setText(_translate("MainWindow", "Capture Image"))
        self.CloseButton.setText(_translate("MainWindow", "Close"))
        self.CreateplaylistButton.setText(_translate("MainWindow", "Create Playlist"))
        self.OpenFileButton.setText(_translate("MainWindow", "Open File"))
        self.menuMenu.setTitle(_translate("MainWindow", "Menu"))
        self.UpdateDatasetButton.setText(_translate("MainWindow", "Update Dataset"))
        self.UpdateModelButton.setText(_translate("MainWindow", "Update Model"))


# import Icons_rc from


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
